The circuit produces the 5-bit Sum = X + Y + Cin,
which is displayed on LED[4:0]

In this demo:

-- X is the value of SW[3:0]
-- Y is the value of SW[7:4]
-- Cin is the value of SW[9]

To use:

1. various values to SW[9] and SW[7:0]
2. check the adder result on the LEDs
